// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Viajante.h"
#include "ViajeroErrante.generated.h"

/**
 * 
 */
UCLASS()
class VIAJEROS_API AViajeroErrante : public AViajante
{
	GENERATED_BODY()

public:
	AViajeroErrante();

	void AlternarManiobras(AActor* _movimiento);
	void Emplear();
	
};
