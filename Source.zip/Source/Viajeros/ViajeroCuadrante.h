// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Viajante.h"
#include "ViajeroCuadrante.generated.h"

/**
 * 
 */
UCLASS()
class VIAJEROS_API AViajeroCuadrante : public AViajante
{
	GENERATED_BODY()

public:
	AViajeroCuadrante();

};
