// Fill out your copyright notice in the Description page of Project Settings.


#include "IMovimiento.h"

// Add default functionality here for any IIMovimiento functions that are not pure virtual.
